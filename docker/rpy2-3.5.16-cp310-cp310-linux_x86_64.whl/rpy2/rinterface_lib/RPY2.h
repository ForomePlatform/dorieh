/* R symbol, environment, and arbitrary data */

struct RPY2_sym_env_data {
  SEXP symbol;
  SEXP environment;
  SEXP data;
};
